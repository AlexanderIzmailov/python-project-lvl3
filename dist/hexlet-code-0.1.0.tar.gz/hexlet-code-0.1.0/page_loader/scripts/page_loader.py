from page_loader import page_loader


def main():
    page_loader()


if __name__ == '__main__':
    main()
