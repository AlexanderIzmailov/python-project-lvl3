def page_loader():
    print("AAA")
